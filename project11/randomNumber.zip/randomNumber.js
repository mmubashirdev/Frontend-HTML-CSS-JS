do {
  let guess = prompt("Guess the number");
  let randomNum = Math.random()*10;
  let attempts = 0;
  let exit = "no"
  for(let attempts = 0;attempts<10;attempts++){
  if(guess == randomNum){
    alert("Correct answer you win")
    alert("Number of attempts:", attempts)
  }else if(guess < randomNum){
    alert("Too low guess")
    attempts++;
  }else if(guess > randomNum){
    alert("Too high guess")
    attempts++;
  }
}
  if(attempts == 10){
    alert("Game Over Attempt limit reached")
    alert("The correct number was",randomNum)
  }
} while (exit == "yes");